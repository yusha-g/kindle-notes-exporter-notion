Author: Fredrik Backman

### 17 September 2023

- loc 71-72\
*[08:27:14]*\
“Falling in love with her meant having no room in his own body.”

- loc 90\
*[08:31:06]*\
*~ Loosing yourself to old age. The square is his memory or his imagination - his mind.*\
How do I explain that I’m going to be leaving him even before I die?
