Author: Tomasz Jedrowski

### 1 January 2024
- page 4 | loc 60-61 \
*[14:38:50]*\
Some people, some events, make you lose your head. They’re like guillotines, cutting your life in two, the dead and the alive, the before and the after.

- page 11 | loc 166-166 \
*[18:17:05]*\
I felt elated, suddenly high on the possibilities of the dark, and some unknown barrier receded in my mind.

- page 12 | loc 173-174 \
*[18:18:46]* \
shame. It was like a newly grown organ, monstrous and pulsating and suddenly part of me.

- page 17 | loc 256-257 | \
*[23:29:43]* \
Selfish. Growing into yourself is nothing but that.


- page 20 | loc 302-303 \
*[23:43:43]* \
at—returned to me with even greater intensity than I had lived them. The law of gravity applies to memories too.

### 2 January 2024

- page 17 | loc 249-250 \
*[22:31:56]* \
I had always liked the act of leaving, the expanse between departure and arrival when you’re seemingly nowhere, defined by another kind of time.


- page 21 | location 319 \
*[08:56:05]* \
*~ Revisit this* \
*It was the same anger and weariness I’d observed in my schoolteachers, those who struggled to believe in the system yet punished others for doing the same.*


### 3 January 2024
- page 28 | loc 430-431 \
*[09:31:31]*\
“We give and take love for one night, maybe a couple of weeks. But not longer than that. There is too much resentment. Too much hatred. You live for pleasure if you’re like this, and

- page 32 | loc 488-488 \
*[09:44:31]* \
I avoided you, so that you couldn’t avoid me. I didn’t want to be in the field of your power.

### 4 January 2024
- page 31 | loc 461 \
*[08:56:49]* \
*~ The writing is so very romantic. He describes the name with such care and intensity*\
Two syllables that rise and fall and follow each other logically, almost inevitably, and whose sound together is so familiar, so natural, that the meaning of its parts remained hidden to me until years later: Ja, meaning “I” in our language, and nusz, sounding just like our word for “knife.”
